import json
from enum import Enum
from colorama import Fore, Style
from user_scanner.core.helpers import ScanConfig

# Added {url} to the debug message
DEBUG_MSG = """Result {{
  status: {status},
  reason: "{reason}",
  username: "{username}",
  site_name: "{site_name}",
  category: "{category}",
  url: "{url}",
  extra: "{extra}",
  is_email: "{is_email}"
}}"""

# Added "url": "{url}" to the JSON template
JSON_TEMPLATE = """{{
\t"username": "{username}",
\t"category": "{category}",
\t"site_name": "{site_name}",
\t"status": "{status}",
\t"url": "{url}",
\t"extra": "{extra}",
\t"reason": "{reason}"
}}"""

# Added {url} to the CSV template
CSV_TEMPLATE = "{username},{category},{site_name},{status},{url},{extra},{reason}"


def humanize_exception(e: Exception) -> str:
    msg = str(e).lower()

    if "10054" in msg:
        return "Connection closed by remote server"
    if "11001" in msg:
        return "Could not resolve hostname"

    if "errno 7" in msg or "no address associated with hostname" in msg:
        return "No internet connection or DNS failure"

    if "errno 101" in msg or "network is unreachable" in msg:
        return "Network unreachable (Is your internet on?)"

    return str(e)


class Status(Enum):
    TAKEN = 0
    AVAILABLE = 1
    ERROR = 2
    SKIPPED = 3

    def to_label(self, is_email=False):
        if self == Status.ERROR:
            return "Error"
        elif self == Status.SKIPPED:
            return "Skipped"
        if is_email:
            return "Registered" if self == Status.TAKEN else "Not Registered"
        return "Found" if self == Status.TAKEN else "Not Found"

    def __str__(self):
        return self.to_label(is_email=False)


class Result:
    def __init__(self, status: Status, reason: str | Exception | None = None, **kwargs):
        self.status = status
        self.reason = reason
        self.username = None
        self.site_name = None
        self.category = None
        self.url = ""  # Initialized url field
        self.extra = ""
        self.is_email = False
        self.update(**kwargs)

    def update(self, **kwargs):
        # Added "url" to the list of fields allowed for dynamic updates
        for field in ("username", "site_name", "category", "is_email", "url", "extra"):
            if field in kwargs and kwargs[field] is not None:
                setattr(self, field, kwargs[field])
        return self

    @classmethod
    def taken(cls, reason: str | Exception | None = None, **kwargs):
        return cls(Status.TAKEN, reason, **kwargs)

    @classmethod
    def available(cls, reason: str | Exception | None = None, **kwargs):
        return cls(Status.AVAILABLE, reason, **kwargs)

    @classmethod
    def error(cls, reason: str | Exception | None = None, **kwargs):
        return cls(Status.ERROR, reason, **kwargs)

    @classmethod
    def skipped(cls, reason: str | Exception | None = None, **kwargs):
        return cls(Status.SKIPPED, reason, **kwargs)

    @classmethod
    def from_number(cls, i: int, reason: str | Exception | None = None):
        try:
            status = Status(i)
        except ValueError:
            return cls(Status.ERROR, "Invalid status. Please contact maintainers.")
        return cls(status, reason)

    def to_number(self) -> int:
        return self.status.value

    def has_reason(self) -> bool:
        return self.reason is not None

    def get_reason(self) -> str:
        if self.status == Status.SKIPPED and self.reason is None:
            return "Notifies the target by forgot password email or similar"

        if self.reason is None:
            return ""

        if isinstance(self.reason, str):
            return self.reason

        msg = humanize_exception(self.reason)
        return f"{type(self.reason).__name__}: {msg.capitalize()}"

    def as_dict(self) -> dict:
        return {
            "status": self.status.to_label(self.is_email),
            "reason": self.get_reason(),
            "username": self.username,
            "site_name": self.site_name,
            "category": self.category,
            "url": self.url,  # Added url to dictionary output
            "extra": self.extra,
            "is_email": self.is_email,
        }

    def to_dict(self) -> dict:
        """Prepares the clean dictionary for JSON/Exporting."""
        data = self.as_dict()

        if self.is_email:
            data["email"] = data.pop("username")
        data.pop("is_email", None)
        return data

    def debug(self) -> str:
        return DEBUG_MSG.format(**self.as_dict())

    def to_json(self) -> str:
        data = self.as_dict()

        if data.get("extra"):
            # use json.dumps to get a perfectly escaped string, then strip the surrounding quotes
            data["extra"] = json.dumps(str(data["extra"]))[1:-1]
        else:
            data["extra"] = ""

        msg = JSON_TEMPLATE.format(**data)
        if self.is_email:
            msg = msg.replace('\t"username":', '\t"email":')
        return msg


    def to_csv(self) -> str:
        data = self.as_dict()

        # flatten multiline extra string parameters so it doesn't break row alignments
        if data.get("extra"):
            # swap real newlines out for a clean inline separator
            clean_extra = str(data["extra"]).replace("\n", "; ")
            # normalize whitespace sequences
            data["extra"] = " ".join(clean_extra.split())
        else:
            data["extra"] = ""

        return CSV_TEMPLATE.format(**data)

    def __str__(self):
        return self.get_reason()

    def __eq__(self, other):
        if isinstance(other, Status):
            return self.status == other
        if isinstance(other, Result):
            return self.status == other.status
        if isinstance(other, int):
            return self.to_number() == other
        return NotImplemented

    def get_output_color(self) -> str:
        if self == Status.ERROR:
            return Fore.YELLOW
        elif self == Status.SKIPPED:
            return Fore.WHITE
        else:
            return Fore.GREEN if self == Status.TAKEN else Fore.RED

    def get_output_icon(self) -> str:
        if self == Status.ERROR:
            return "[!]"
        elif self == Status.SKIPPED:
            return "[~]"
        else:
            return "[✔]" if self == Status.TAKEN else "[✘]"

    def get_console_output(self, configs: ScanConfig | None = None) -> str:
        site_name = self.site_name
        status_text = self.status.to_label(self.is_email)
        username = ""
        if self.username:
            username = f"({self.username})"
        color = self.get_output_color()
        icon = self.get_output_icon()

        # Added logic to include URL in console output if show_url is True
        ## Color the URL in white for better visibility
        url_display = (
            f" {Fore.WHITE}[{self.url}]{color}"
            if (configs and configs.verbose) and self.url
            else ""
        )

        # dynamic extra layout handling logic
        extra_display = ""
        if self.extra:
            # cast to string just in case, and split by newline or custom delimiter
            extra_str = str(self.extra)

            # clean up empty lines and split by newline
            extra_lines = [line.strip() for line in extra_str.split("\n") if line.strip()]

            # draw a tree link for each line
            formatted_lines = []
            for line in extra_lines:
                formatted_lines.append(f"\n{' ' * 6}{Fore.CYAN}└── {line}")

            extra_display = "".join(formatted_lines)
        reason = f" ({self.get_reason()})" if self.has_reason() else ""

        return f"  {color}{icon} {site_name}{url_display} {username}: {status_text}{reason}{extra_display}{Style.RESET_ALL}"

    def is_found(self) -> bool:
        """Returns True if the target was found or registered (Status.TAKEN)"""
        return self.status == Status.TAKEN

    def show(self, configs: ScanConfig):
        """Prints the console output and returns itself for chaining.
        If only_found is True, only results with Status.TAKEN are printed."""
        # Updated show() to accept and pass the show_url flag
        if configs.only_found and self.status != Status.TAKEN:
            return self
        print(self.get_console_output(configs))
        return self
